//------------------------------------------------------------------------------
// Copyright (c) WAGO Kontakttechnik GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     cmptestcmd.h
///
///  \brief    module to use CoDeSys runtime system for gTest enveroment.
///
///  \author   Jobst Wellensiek : WAGO Kontakttechnik GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_CMPTESTCMD_H_
#define INC_CMPTESTCMD_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdbool.h>
//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
#if defined(__linux__) // Linux
#define API_EXPORT __attribute__((visibility("default")))
#else // !Linux
#error "OS not supported yet (to set public visibility)"
#define API_EXPORT
#endif


typedef struct cmptestcmd_rts cmptestcmd_rts_type;


//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

//------------------------------------------------------------------------------
/// Construct the enveroment for using a Component of CoDeSys runtime system
///
/// \param pRtsHandle
///   Handle for deal with runtime system
/// \param szComponent
///   component to test
/// \return
///   true if construction is successfull otherwise false
//------------------------------------------------------------------------------
API_EXPORT  bool cmptestcmd_Construct(cmptestcmd_rts_type ** ppRtsHandle, char const * const  szComponent[], int amount);

//------------------------------------------------------------------------------
/// Destruct the enveroment for using a Component of CoDeSys runtime system
///
/// \param pRtsHandle
///   Handle for deal with runtime system
/// \param fDeleteLog
///   if true the runtime logfile is not deleted. For purpose of valuation only.
//------------------------------------------------------------------------------
API_EXPORT void cmptestcmd_Destruct(cmptestcmd_rts_type * pRtsHandle, bool fDeleteLog);

//------------------------------------------------------------------------------
/// Load a CoDeSys project
/// File can be created by using boot project build in CoDeSys IDE
///
/// \param pRtsHandle
///   Handle for deal with runtime system
/// \return
///   true if construction is successfull otherwise false
//------------------------------------------------------------------------------
API_EXPORT bool cmptestcmd_LoadProject(cmptestcmd_rts_type * pRtsHandle, char const * const szProjekt);

//------------------------------------------------------------------------------
/// Start the runtime system if a CoDeSys project exist.
/// If no project is on the system the start fail.
///
/// \param pRtsHandle
///   Handle for deal with runtime system
/// \return
///   true if construction is successfull otherwise false
//------------------------------------------------------------------------------
API_EXPORT bool cmptestcmd_Start(cmptestcmd_rts_type * pRtsHandle);

//------------------------------------------------------------------------------
/// Stop the runtime system
///
/// \param pRtsHandle
///   Handle for deal with runtime system
//------------------------------------------------------------------------------
API_EXPORT void cmptestcmd_Stop(cmptestcmd_rts_type * pRtsHandle);

//------------------------------------------------------------------------------
/// Different types of reset
///
/// Warm reset: Resets all global data except retain data
/// Cold reset: Resets all global data *and* retain data
/// Origin reset: Deletes the application and all its files (bootproject etc.)
///               and resets all global and retain data
//------------------------------------------------------------------------------
enum ResetType
{
  RESET_WARM,
  RESET_COLD,
  RESET_ORIGIN
};

//------------------------------------------------------------------------------
/// Reset the runtime system
///
/// \param pRtsHandle
///   Handle for deal with runtime system
/// \param eResetOption
///   The type of reset to perform (see \ref ResetType)
//------------------------------------------------------------------------------
API_EXPORT void cmptestcmd_Reset(cmptestcmd_rts_type * pRtsHandle, enum ResetType eResetOption);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus


#endif /* INC_CMPTESTCMD_H_ */
//---- End of source file ------------------------------------------------------
