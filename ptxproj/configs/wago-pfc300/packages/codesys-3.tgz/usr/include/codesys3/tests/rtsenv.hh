//------------------------------------------------------------------------------
// Copyright (c) WAGO Kontakttechnik GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     rtsenv.hh
///
///  \brief    frame to include codesys as a box in the test framework gtest.
///
///  \author   Jobst Wellensiek : WAGO Kontakttechnik GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_RTSENV_HH_
#define INC_RTSENV_HH_

#include <gtest/gtest.h>
#include <codesys3/tests/cmptestcmd.h>

#define MAX_COMPONENTS 30
#define MAX_COMPONENTS_PAHT 200

typedef enum
{
  RTS_init,
  RTS_run,
  RTS_down
} RtsState_eType;

class RtsEnvironment : public ::testing::Environment
{
public:
  RtsEnvironment(char const * const components[], int amount) :
      m_fDeleteLog(true),
      m_Inizialized(false),
      pRts(nullptr),
      m_Components(components),
      m_AmoutOfComponents(amount)
  {
  }

  ~RtsEnvironment() override = default;

  void TearDown() override
  {
    RtsDown();
  }

  RtsState_eType GetState()
  {
    RtsState_eType eResult = RTS_init;

    if (m_Inizialized)
    {
      eResult = RTS_down;
      if (pRts != NULL)
      {
        eResult = RTS_run;
      }
    }

    return eResult;
  }

  bool RtsStart()
  {
    bool fResult = false;

    if (pRts == NULL)
    {
      fResult = cmptestcmd_Construct(&pRts, m_Components, m_AmoutOfComponents);
      m_Inizialized = true;
    }
    else
    {
      cmptestcmd_Reset(pRts, RESET_ORIGIN);
    }

    return fResult;
  }

  void RtsDown()
  {
    if (pRts != nullptr)
    {
      cmptestcmd_Destruct(pRts, m_fDeleteLog);
      pRts = nullptr;
    }
  }

  void RtsStop()
  {
    if (pRts != nullptr)
    {
      cmptestcmd_Reset(pRts, RESET_ORIGIN);
    }
  }

  bool LoadProject(char const * const szProjekt)
  {
    bool fResult = false;

    if (pRts != nullptr)
    {
      fResult = cmptestcmd_LoadProject(pRts, szProjekt);
    }

    return fResult;
  }

  void Reset(ResetType type)
  {
    if (pRts != nullptr)
    {
      cmptestcmd_Reset(pRts, type);
    }
  }

  bool Start(void)
  {
    bool fResult = false;

    if (pRts != nullptr)
    {
      fResult = cmptestcmd_Start(pRts);
    }

    return fResult;
  }

  void Stop(void)
  {
    if (pRts != nullptr)
    {
      cmptestcmd_Stop(pRts);
    }
  }

  void DeleteLogFile(bool fDeleteLog)
  {
    printf("!!!!! For Analyse Log File set deleting to %d !!!!!!\n", fDeleteLog);
    m_fDeleteLog = fDeleteLog;
  }

protected:
  bool m_fDeleteLog;
  bool m_Inizialized;
  cmptestcmd_rts_type * pRts;
  const char * const * m_Components;
  int m_AmoutOfComponents;
};


class RtsEnvParams
{
public:
  virtual ~RtsEnvParams()
  {
    m_pRts->RtsStop();
  }

  virtual void SetUp() = 0;
  virtual void TearDown() = 0;

  RtsEnvParams(RtsEnvironment * pRts) :
    RtsEnvParams(true, pRts)
  {
  }

  RtsEnvParams(bool start, RtsEnvironment * pRts)
  {
    m_pRts = pRts;

    if ((m_pRts != nullptr) && (start == true) && m_pRts->GetState() == RTS_init)
    {
      m_pRts->RtsStart();
    }
  }

  bool LoadProject(char const * const szProjekt)
  {
    Reset();
    return m_pRts->LoadProject(szProjekt);
  }

  void Reset(ResetType type = RESET_ORIGIN)
  {
    m_pRts->Reset(type);
  }

  bool Start()
  {
    return m_pRts->Start();
  }

  void Stop()
  {
    m_pRts->Stop();
  }

  void DeleteLogFile(bool fDeleteLog)
  {
    m_pRts->DeleteLogFile(fDeleteLog);
  }

  RtsState_eType GetState()
  {
    return m_pRts->GetState();
  }

  void RtsDown()
  {
    if (m_pRts->GetState() == RTS_run)
    {
      m_pRts->RtsDown();
    }
  }

  RtsEnvironment * m_pRts;
};

template <class T>
class RtsEnvClass : public ::testing::Test
{
public:
  virtual ~RtsEnvClass()
  {
    delete pParams;
    pParams = 0;
  }

protected:
  RtsEnvClass() : pParams(0)
  {
    pParams = new T();
  }

  void SetUp() override
  {
    pParams->SetUp();
  }

  void TearDown() override
  {
    pParams->TearDown();
  }

  T * pParams;
};

#endif
