//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libkbusfwload.h
///
///  \brief    Library for FW-Update of RENESAS Slave CPU (KBUS)
///
///  \author   Tobias Biehl : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_LIBKBUSFWLOAD_H_
#define INC_LIBKBUSFWLOAD_H_

#include "wc/api_export.h"
#include <stddef.h>

// Tell compiler and linker that the functions declared with this macro should
// not be removed from the .so API. LIBKBUSFWLOAD_API will be set to
// WC_API_EXPORT when the implementing project is compiled.
#ifndef LIBKBUSFWLOAD_API
  #define LIBKBUSFWLOAD_API
#endif

/// Type of Firmware (FW or FWL)
enum fw_type {
	FW_TYPE_FIRMWARE, ///< Firmware (FW)
	FW_TYPE_FWL,      ///< Firmware Loader (FWL) / Bootloader
};

/// Skip SPI Start Update Commando (e.g. FWL is already in Update State)
#define KFWL_SKIP_SPI_UPDATE_CMD	1

//-- Function: kfwl_get_version ------------------------------------------------
///
///  Get Version of currently running Firmware in Slave CPU
///
///  \param  type     Type of artifact to extract version from:
///                   FW_TYPE_FIRMWARE: Firmware version
///                   FW_TYPE_FWL: Fimware-Loader (Bootloader) version
///
///  \return  Version-String on success (Vaa.bb.cc (ii) yyyy-mm-ddThh:mm:ss)
///           NULL on failure and errno is set appropriately, e.g.
///           EINVAL  Invalid arguments
///           EIO     SPI communication error
///           ENOENT  path to SPI device does not exist
///
//------------------------------------------------------------------------------
LIBKBUSFWLOAD_API const char *kfwl_get_version(enum fw_type type);

//-- Function: kfwl_update -----------------------------------------------------
///
///  Load new Firmware from fw_binary_path into Slave CPU
///
///  \param  fw_binary_path  Path to Firmware Binary Blob
///          flags           Additional Flags to control update process
///                          \see KFWL_SKIP_SPI_UPDATE_CMD
///
///  \return  0 on success
///           -1 on failure and errno is set appropriately, e.g.
///           EINVAL     Invalid arguments
///           EFAULT     Invalid responses from Slave CPU via UART
///           EIO        SPI communication error
///           ENOENT     path to SPI/UART device does not exist
///           ETIMEDOUT  UART communication timed out
///
//------------------------------------------------------------------------------
LIBKBUSFWLOAD_API int kfwl_load_fw(const char *fw_binary_path, int flags);

#endif /* INC_LIBKBUSFWLOAD_H_ */

