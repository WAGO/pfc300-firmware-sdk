//------------------------------------------------------------------------------
// Copyright (c) WAGO Kontakttechnik GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------

#pragma once

#include <wago/wdx/base_parameter_provider.hpp>

namespace wago::pp_hostdomainname {

  class hostdomainname_parameter_provider final : public ::wago::wdx::base_parameter_provider {

    public:
      hostdomainname_parameter_provider() = default;
      ~hostdomainname_parameter_provider() final = default;
      hostdomainname_parameter_provider(hostdomainname_parameter_provider const&) = delete;
      hostdomainname_parameter_provider const& operator=(hostdomainname_parameter_provider const&) = delete;
      hostdomainname_parameter_provider(hostdomainname_parameter_provider&&) = delete;
      hostdomainname_parameter_provider& operator=(hostdomainname_parameter_provider&&) = delete;

      std::string display_name() override;
      wago::wdx::parameter_selector_response get_provided_parameters() override;

      wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

      wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
        std::vector<wago::wdx::value_request> value_requests) override;

    private:

  };

}
