//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file
///
///  \brief    Parameter Provider for network configuration
///
///  \author   StS : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef NETWORK_PARAMETER_PROVIDER_HPP_
#define NETWORK_PARAMETER_PROVIDER_HPP_

#include <wago/wdx/base_parameter_provider.hpp>

namespace wago::pp_netconf {

class network_parameter_provider final : public ::wago::wdx::base_parameter_provider {
 public:
  network_parameter_provider()                                                   = default;
  ~network_parameter_provider() override                                         = default;
  network_parameter_provider(network_parameter_provider const&)                  = delete;
  network_parameter_provider const& operator=(network_parameter_provider const&) = delete;
  network_parameter_provider(network_parameter_provider&&)                       = delete;
  network_parameter_provider& operator=(network_parameter_provider&&)            = delete;

  std::string display_name() override;
  wago::wdx::parameter_selector_response get_provided_parameters() override;

  wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
      std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

  wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
      std::vector<wago::wdx::value_request> value_requests) override;

  wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values_connection_aware(
      std::vector<wago::wdx::value_request> value_requests, bool deferred) override;

 private:
  class get_handler;
  class set_handler;
};

}  // namespace wago::pp_netconf

#endif /* NETWORK_PARAMETER_PROVIDER_HPP_ */
