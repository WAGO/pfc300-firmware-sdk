# Welcome to WAGO's fork of the u-boot project

This repository contains changes to support WAGO's linux based PFC devices.
Currently this repository supports following PFC devices. 

- [750-8302 (aka PFC300)](../board/wago/pfc-am62x/README.md)

To get further details, build instructions or howtos about the supported devices
click on the devices description.

## Responsibility

This repository is maintained by the members of the Team BaseSoftware. Feel free
to contact any member of the [team](https://svgithub01001.wago.local/orgs/BU-Automation/teams/team-basesoftware-developer-linux/members)
if there any left questions that are not answered by the boards documentation.
